# wechat-payment-for-woocommerce
WeChat Payments for WooCommerce is a Wordpress plugin that allows to accept payments at WooCommerce-powered online stores.